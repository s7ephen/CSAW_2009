Use Pyro's object naming and show the use of the naming functions in the
Nameserver.
