
class computer:
	def __init__(self):
		pass
	def getName(self):
		return "Computer"
	def getDescription(self):
		return "Athlon XP 2400+ game system"
