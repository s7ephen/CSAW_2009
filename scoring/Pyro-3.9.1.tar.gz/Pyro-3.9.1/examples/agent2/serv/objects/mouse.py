
class mouse:
	def __init__(self):
		pass
	def getName(self):
		return "Mouse"
	def getDescription(self):
		return "Optical wireless mouse"
