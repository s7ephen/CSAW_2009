
class boots:
	def __init__(self):
		pass
	def getName(self):
		return "Boots"
	def getDescription(self):
		return "Burton snowboard softboots"
