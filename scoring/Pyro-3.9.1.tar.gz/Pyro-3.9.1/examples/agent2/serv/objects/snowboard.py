
class snowboard:
	def __init__(self):
		pass
	def getName(self):
		return "snowboard"
	def getDescription(self):
		return "Option 'Signature' snowboard"
