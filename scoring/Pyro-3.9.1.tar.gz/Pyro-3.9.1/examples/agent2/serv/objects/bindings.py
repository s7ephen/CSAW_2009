
class bindings:
	def __init__(self):
		pass
	def getName(self):
		return "bindings"
	def getDescription(self):
		return "Flow snowboard bindings"
