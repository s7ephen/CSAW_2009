
class tv:
	def __init__(self):
		pass
	def getName(self):
		return "TV"
	def getDescription(self):
		return "Wide-screen stereo television"
