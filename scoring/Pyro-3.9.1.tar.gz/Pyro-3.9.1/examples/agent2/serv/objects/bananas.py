
class bananas:
	def __init__(self):
		pass
	def getName(self):
		return "bananas"
	def getDescription(self):
		return "six yellow bananas"
