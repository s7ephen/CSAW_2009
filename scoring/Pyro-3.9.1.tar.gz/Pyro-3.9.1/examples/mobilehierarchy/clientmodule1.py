class BaseClass:
	def method(self):
		return "this is the method's result"
