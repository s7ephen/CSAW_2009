import clientmodule1

class SomeClass(clientmodule1.BaseClass):
	pass
