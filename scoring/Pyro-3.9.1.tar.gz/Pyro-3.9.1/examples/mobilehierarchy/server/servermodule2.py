import servermodule1

class SomeClass(servermodule1.BaseClass):
	pass
