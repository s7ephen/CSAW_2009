class BaseClass:
	def method(self):
		return "this is the server object method's result"
