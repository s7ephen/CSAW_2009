Abuse the two logging facilities of Pyro (the system log and the user log).

Output is 2 files: Pyro_sys_log and Pyro_user_log.

You can also try to use PYRO_STDLOGGING, with or without
an appropriate configuration file. (see "logging.cfg")
