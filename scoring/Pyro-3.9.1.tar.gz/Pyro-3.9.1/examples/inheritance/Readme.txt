This is for testing the case where the remote object is a subclass
of some other class(es). The right member function should be called
ofcourse.

