Testing the passing of code from server back to client.
No nameserver is required.
