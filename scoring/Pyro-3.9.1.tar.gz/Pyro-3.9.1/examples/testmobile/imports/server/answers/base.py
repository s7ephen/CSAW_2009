
class AnswerBase:
	def __init__(self):
		pass
	def answerBaseSuffix(self):
		return "(this is suffix from base class)"
