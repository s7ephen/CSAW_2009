
class ClientParameter:
	def __init__(self, name):
		self.name=name
	def method(self):
		print "I am client parameter object ",self.name
