
class ResultParameter:
	def __init__(self, name):
		self.name=name
	def method(self):
		print "I am resultparameter object ",self.name
